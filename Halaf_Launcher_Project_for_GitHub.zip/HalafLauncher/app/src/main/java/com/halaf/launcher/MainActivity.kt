package com.halaf.launcher

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class TvApp(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HalafHome() }
    }
}

@Composable
fun HalafHome() {
    val context = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<TvApp>()) }
    var showSettings by remember { mutableStateOf(false) }
    var theme by remember { mutableStateOf("blue") }
    var language by remember { mutableStateOf("ar") }

    val accent = when (theme) {
        "purple" -> Color(0xFFB66CFF)
        "red" -> Color(0xFFFF555D)
        else -> Color(0xFF258BFF)
    }
    val bg = Brush.verticalGradient(listOf(Color(0xFF101827), Color(0xFF05080F)))

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
                .mapNotNull { info ->
                    val packageName = info.activityInfo?.packageName ?: return@mapNotNull null
                    if (packageName == context.packageName) return@mapNotNull null
                    TvApp(info.loadLabel(pm).toString(), packageName, info.loadIcon(pm))
                }
                .distinctBy { it.packageName }
                .sortedBy { it.label.lowercase() }
        }
    }

    MaterialTheme {
        Box(
            Modifier.fillMaxSize().background(bg).padding(horizontal = 42.dp, vertical = 28.dp)
        ) {
            Column(Modifier.fillMaxSize()) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text("HALAF", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                        Text("LAUNCHER", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
                    }
                    Text(SimpleDateFormat("EEE, dd MMM  •  HH:mm", Locale.getDefault()).format(Date()),
                        color = Color(0xFFB9C5D6), fontSize = 17.sp)
                    Spacer(Modifier.width(22.dp))
                    GlassAction("⚙  الإعدادات", accent) { showSettings = true }
                }

                Spacer(Modifier.height(34.dp))
                Text(if (language == "ar") "تطبيقاتك" else if (language == "tr") "Uygulamalarınız" else if (language == "fr") "Vos applications" else "Your apps",
                    color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))

                if (apps.isEmpty()) {
                    Text("جارٍ تحميل التطبيقات…", color = Color.LightGray, fontSize = 18.sp)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(18.dp)) {
                        items(apps.chunked(6)) { rowApps ->
                            Row(
                                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(18.dp)
                            ) {
                                rowApps.forEach { app ->
                                    AppTile(app = app, accent = accent) {
                                        val launch = context.packageManager.getLaunchIntentForPackage(app.packageName)
                                        if (launch != null) context.startActivity(launch)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Text("HALAF LAUNCHER  •  v0.1.0", modifier = Modifier.align(Alignment.BottomEnd),
                color = Color(0xFF526176), fontSize = 10.sp, letterSpacing = 1.5.sp)
        }
    }

    if (showSettings) {
        Dialog(onDismissRequest = { showSettings = false }) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
                    .background(Color(0xF0182233)).border(1.dp, Color(0x553B9DFF), RoundedCornerShape(26.dp))
                    .padding(26.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("إعدادات Halaf Launcher", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("الثيم", color = Color(0xFFB8C7D9), fontSize = 16.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ThemeChoice("أزرق", Color(0xFF258BFF), theme == "blue") { theme = "blue" }
                    ThemeChoice("أرجواني", Color(0xFFB66CFF), theme == "purple") { theme = "purple" }
                    ThemeChoice("أحمر", Color(0xFFFF555D), theme == "red") { theme = "red" }
                }
                Text("اللغة", color = Color(0xFFB8C7D9), fontSize = 16.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf("العربية" to "ar", "Türkçe" to "tr", "English" to "en", "Français" to "fr").forEach { (label, code) ->
                        ThemeChoice(label, accent, language == code) { language = code }
                    }
                }
                Text("الأرقام: 0 1 2 3 4 5 6 7 8 9", color = Color.White, fontSize = 15.sp)
                Text("إعدادات الخطوط والخلفيات والودجت والنسخ الاحتياطي ستضاف في الإصدارات التالية.",
                    color = Color(0xFF9EADC0), fontSize = 13.sp)
                GlassAction("إغلاق", accent) { showSettings = false }
            }
        }
    }
}


fun drawablePainter(drawable: android.graphics.drawable.Drawable): androidx.compose.ui.graphics.painter.BitmapPainter {
    val width = drawable.intrinsicWidth.coerceAtLeast(1)
    val height = drawable.intrinsicHeight.coerceAtLeast(1)
    val bitmap = android.graphics.Bitmap.createBitmap(
        width, height, android.graphics.Bitmap.Config.ARGB_8888
    )
    val canvas = android.graphics.Canvas(bitmap)
    drawable.setBounds(0, 0, canvas.width, canvas.height)
    drawable.draw(canvas)
    return androidx.compose.ui.graphics.painter.BitmapPainter(bitmap.asImageBitmap())
}

@Composable
fun AppTile(app: TvApp, accent: Color, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(
        Modifier.width(142.dp).onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(22.dp))
            .background(if (focused) Color(0x553B8DFF) else Color(0x331C2B40))
            .border(if (focused) 2.dp else 1.dp, if (focused) accent else Color(0x445F7898), RoundedCornerShape(22.dp))
            .clickable(onClick = onClick).focusable().padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        androidx.compose.foundation.Image(
            painter = remember(app.icon) { drawablePainter(app.icon) },
            contentDescription = app.label,
            modifier = Modifier.size(66.dp)
        )
        Spacer(Modifier.height(10.dp))
        Text(app.label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, textAlign = TextAlign.Center)
    }
}

@Composable
fun GlassAction(label: String, accent: Color, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.onFocusChanged { focused = it.isFocused }.clip(RoundedCornerShape(16.dp))
            .background(Color(0x44263D59))
            .border(if (focused) 2.dp else 1.dp, if (focused) accent else Color(0x555F7898), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).focusable().padding(horizontal = 18.dp, vertical = 12.dp)
    ) { Text(label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun ThemeChoice(label: String, color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = if (selected) 0.35f else 0.12f))
            .border(if (selected) 2.dp else 1.dp, color, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick).focusable().padding(horizontal = 12.dp, vertical = 10.dp)
    ) { Text(label, color = Color.White, fontSize = 13.sp) }
}
